import './Chatwindow.css';
// import './css/MDBootstrap/css/core.min.css';
// import './css/fontawesome/css/all.css';
// import './css/fontawesome/css/all.min.css';
import { Link } from 'react-router-dom';
import Skeleton from "react-loading-skeleton";
// 3
import { useSearchParams } from 'react-router-dom';
import { useEffect , useContext , useRef , useState } from 'react';
import $ from "jquery" ;
import axios from 'axios';
// import io from "socket.io-client"; 
import {SocketContext} from './App';

var socket='';
var el='';
function sendmessage(){  
  el=document.getElementById('messages_div');

  var msg=$('#message').val();
  if(msg!=''){       
  $('#messages_div').append('<div class="msg_rec_div">'+msg+'</div>');
  $('#message').val('');  
  socket.emit('send_message',[msg,id,localStorage.getItem('userIds')]);
  }else{
    return false;
  }  

  el.scrollIntoView({behavior: "smooth",block: "end"});
  el.scrollTop=el.scrollHeight;
}
 

var id='';
var ownId='';

function Chatwindow(){            
  socket = useContext(SocketContext);
  const [isLoading2,setIsLoading2] = useState(true);
  
  useEffect(()=>{   
    
    $('.mobile-bottom-nav').hide();
    // socket.off('received_msg').on('received_msg',function(data){      
    //   $('#messages_div').append('<div class="msg_sent_div" >'+data[0]+'</div>');
      
    //   if($('#msg_view').val()==data[1]){
    //     socket.emit('update_msg',[localStorage.getItem('userIds'),data[1],data[2],1]); 
    //     $('#msg_text_'+id).html(data[0]);
    //   }else{
    //     socket.emit('update_msg',[localStorage.getItem('userIds'),data[1],data[2],0]);
    //     $('#msg_text_'+id).html('<strong>'+data[0]+'</strong>');
    //   }

    //   el=document.getElementById('messages_div');
    //   if(el){
    //   el.scrollIntoView({behavior: "smooth",block: "end"});   
    //   el.scrollTop=el.scrollHeight;   
    //   }
    // })

  },[socket])

  const [searchParams, setSearchParams] = useSearchParams();

  id = searchParams.get('id'); 
  $('#msg_view').val(id); 
  ownId=localStorage.getItem('userIds');  

const [user_chat , user_chats] = useState([]);
const [user_name , user_names ] = useState([]);
const messageEl = useRef(null);
const [msgs , msg ] = useState([]);

useEffect(()=>{
  setIsLoading2(true);
axios.post('http://192.168.68.100:9999/user_chat',{id:id,ownId:ownId}).then((response) =>{  
  el=document.getElementById('messages_div');
  
  var dataBack=response;    
  if(dataBack.data.chat_return1.length!=0){
    setIsLoading2(false);
    user_chats(dataBack.data.chat_return1);  
  }   
  if(dataBack.data.chat_return2.length!=0){
    setIsLoading2(false);
    user_names(dataBack.data.chat_return2);
  }    
  if(dataBack.data.displayMsgArray.length!=0){  
    setIsLoading2(false);   
    setTimeout(function(){
      $('#messages_div').html(dataBack.data.displayMsgArray[0]);   
    },10)            
  }    
  if(el){
  el.scrollIntoView({behavior: "smooth",block: "end"});  
  el.scrollTop=el.scrollHeight;
  }
  })

},[])
    return(  
      
      isLoading2 ?  (


<div>
<div className="main-body">
   <div style={{padding: "5px 25px 10px 5px",borderBottom: "2px solid #fff7f7",display:"flex"}}>
<div className="aligned-center">
  <input type='hidden' id="msg_view" />
<div className="aligned-center">
<div className="head-text">
<Link to={{pathname:'/Allusers'}} className="back-button-main"> <i className="fa-solid fa-angle-left"></i></Link>  
</div>
    <div className="head-text">
        <Skeleton variant="circular" height={60} width={60} className="chatwindow-image-skull"/>
        {/* <div style={{height:"60px",width:"60px"}}></div> */}
    </div>
    <div className="head-text">

    <div style={{fontSize: "20px"}}><Skeleton variant="rectangle" width={70} height={25}/></div>

    </div>
    </div>
    </div>
    <div style={{display:" flex",alignItems:"center"}}>
    <i className="fa fa-ellipsis-v" aria-hidden="true"></i>
    </div>
</div>        
</div>  
<div className="chat-head">
<div className="chat-body" >
<div className='chat-body-skull'>
<div><Skeleton width={100} variant="rectangular" className='left-text'/></div>
<div><Skeleton width={60} variant="rectangular" className='right-text'/></div>
<div><Skeleton width={80} variant="rectangular" className='left-text'/></div>
<div><Skeleton width={100} variant="rectangular" className='right-text'/></div>
<div><Skeleton width={80} variant="rectangular" className='left-text'/></div>
<div><Skeleton width={80} variant="rectangular" className='right-text'/></div>
<div><Skeleton width={90} variant="rectangular" className='right-text'/></div>
<div><Skeleton width={80} variant="rectangular" className='left-text'/></div>
<div><Skeleton width={100} variant="rectangular" className='left-text'/></div>
<div><Skeleton width={120} variant="rectangular" className='left-text'/></div>
<div><Skeleton width={110} variant="rectangular" className='right-text'/></div>
<div><Skeleton width={90} variant="rectangular" className='right-text'/></div>
<div><Skeleton width={80} variant="rectangular" className='left-text'/></div>
<div><Skeleton width={85} variant="rectangular" className='right-text'/></div>
<div><Skeleton width={80} variant="rectangular" className='left-text'/></div>
<div><Skeleton width={90} variant="rectangular" className='right-text'/></div>
<div><Skeleton width={80} variant="rectangular" className='left-text'/></div>
<div><Skeleton width={80} variant="rectangular" className='left-text'/></div>
<div><Skeleton width={90} variant="rectangular" className='right-text'/></div>
</div>
</div>
<div className="footer_chatbox">
<div className="footer_chatitems">
    <textarea type="text" rows="1" id="message" placeholder="Type message..." style={{outline: "none",border: "none",borderBottom: "1px solid #6c6565",width: "66%"}}></textarea>
    <i className="fa-sharp fa-solid fa-face-smile"></i>
    <i className="fa-solid fa-paperclip"></i>
    <i className="fa-sharp fa-solid fa-paper-plane" onClick={sendmessage}></i>                
</div>
</div>
</div>
</div> 


      ):(

 
        <div>
        <div className="main-body">
           <div style={{padding: "5px 25px 10px 5px",borderBottom: "2px solid #fff7f7",display:"flex"}}>
        <div className="aligned-center">
          <input type='hidden' id="msg_view" />
        <div className="aligned-center">
        <div className="head-text">
        <Link to={{pathname:'/Allusers'}} className="back-button-main"> <i className="fa-solid fa-angle-left"></i></Link>  
        </div>
            <div className="head-text">
                <div style={{backgroundImage: "url(../default.png)",backgroundRepeat: "no-repeat",backgroundPosition:"center",borderRadius:"60px",backgroundSize:"cover"}}><div style={{height:"60px",width:"60px"}}></div></div>
            </div>
            <div className="head-text">
                
                { 
      
      user_name.map(function (item,index){
     return <div style={{fontSize: "20px"}} key={item.user_id}>{item.name}</div>
      })
      
      }
                </div>
            </div>
            </div>
            <div style={{display:" flex",alignItems:"center"}}>
            <i className="fa fa-ellipsis-v" aria-hidden="true"></i>
            </div>
        </div>        
    </div>  
  <div className="chat-head" id="messages_view">
    <div className="chat-body" id="messages_div">
    </div>
    <div className="footer_chatbox">
        <div className="footer_chatitems">
            <textarea type="text" rows="1" id="message" placeholder="Type message..." style={{outline: "none",border: "none",borderBottom: "1px solid #6c6565",width: "66%"}}></textarea>
            <i className="fa-sharp fa-solid fa-face-smile"></i>
            <i className="fa-solid fa-paperclip"></i>
            <i className="fa-sharp fa-solid fa-paper-plane" onClick={sendmessage}></i>                
        </div>
    </div>
    </div>
    </div>  

     
      )

  

    )
}

export default Chatwindow;